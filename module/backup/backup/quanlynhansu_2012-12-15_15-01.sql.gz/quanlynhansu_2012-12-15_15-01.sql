#SKD101|quanlynhansu|20|2012.12.15 15:01:34|114|11|2|7|6|8|13|10|4|4|6|1|5|10|2|4|5|3|4|5|4

DROP TABLE IF EXISTS `tlb_bangcap`;
CREATE TABLE `tlb_bangcap` (
  `bang_cap_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_bang_cap` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`bang_cap_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_bangcap` VALUES
('BTVH', 'Bổ túc văn hóa'),
('CD001', 'Cao đẳng'),
('DH001', 'Đại học xây dựng'),
('DH002', 'Đại học luật'),
('DH003', 'Đại học'),
('LDPT', 'Lao động phổ thông'),
('TC001', 'Trung cấp xây dựng'),
('TC002', 'Trung cấp CNTT'),
('TC003', 'Trung cấp'),
('THCS01', 'Trung học cơ sở'),
('THPT01', 'Trung học phổ thông');

DROP TABLE IF EXISTS `tlb_baohiem`;
CREATE TABLE `tlb_baohiem` (
  `ma_nhan_vien` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `so_bhxh` varchar(25) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ngay_cap_bhxh` varchar(25) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `noi_cap_bhxh` varchar(100) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `so_bhyt` varchar(25) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ngay_cap_bhyt` varchar(25) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `noi_cap_bhyt` varchar(100) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`ma_nhan_vien`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_baohiem` VALUES
('TCHC002', '56875657322', '2008-04-04', 'BHXH Đồng Tháp', '5768678654', '2010-01-01', 'BHXH Đồng Tháp'),
('TCHC008', '32351425841', '02/03/2008', 'BHXH Đồng Tháp', '215428572545', '01/01/2011', 'BHXH Đồng Tháp');

DROP TABLE IF EXISTS `tlb_chucvu`;
CREATE TABLE `tlb_chucvu` (
  `chuc_vu_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_chuc_vu` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`chuc_vu_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_chucvu` VALUES
('BGD002', 'Phó giám đốc'),
('BGD01', 'Giám đốc'),
('DT001', 'Đội trưởng'),
('NV001', 'Nhân viên'),
('PTP001', 'Phó trưởng phòng'),
('TGD', 'Tổng giám đốc'),
('TP001', 'Trưởng phòng');

DROP TABLE IF EXISTS `tlb_congviec`;
CREATE TABLE `tlb_congviec` (
  `ma_nhan_vien` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `ngay_vao_lam` varchar(25) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `phong_ban_id` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `cong_viec_id` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `chuc_vu_id` varchar(15) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `muc_luong_cb` varchar(30) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `he_so` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `phu_cap` varchar(30) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `so_sld` varchar(30) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `ngay_cap` varchar(25) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `noi_cap` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `tknh` varchar(30) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `ngan_hang` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `hoc_van_id` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `bang_cap_id` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `ngoai_ngu_id` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `tin_hoc_id` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `dan_toc_id` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `quoc_tich_id` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `ton_giao_id` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `tinh_thanh_id` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  PRIMARY KEY (`ma_nhan_vien`,`phong_ban_id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `tlb_congviec` VALUES
('TCHC008', '02/02/2008', 'PTCHC', 'CNTT', 'NV001', '2000000', '2', NULL, NULL, NULL, NULL, NULL, 'Đầu Tư Đồng Tháp', 'HV005', 'TC002', 'AV000', 'TH002', 'DT001', 'QT001', '1', 'TT001'),
('TCHC002', '2000-02-02', 'PTCHC', 'ATLD', 'PTP001', '2000000', '1.5', NULL, NULL, NULL, NULL, NULL, NULL, 'HV005', 'TC002', 'AV001', 'TH001', 'DT001', 'QT001', '1', 'TT001'),
('TCHC003', '2008-01-01', 'PKH', 'VT001', 'NV001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'HV005', 'DH001', 'AV001', 'TH001', 'DT001', 'QT001', '1', 'TT001'),
('TCKT005', '2008-02-02', 'PKH', 'ATLD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'HV005', 'DH001', 'AV001', 'TH001', 'DT001', 'QT001', '1', 'TT001'),
('TCHC001', '2008-02-02', 'PTCHC', 'ATLD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'HV005', 'CD001', 'AV001', 'TH001', 'DT001', 'QT001', '1', 'TT001'),
('TCHC003', '20/02/2005', 'PTCHC', 'TX001', 'NV001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'HV001', 'CD001', 'AV000', 'TH000', 'DT001', 'QT001', '1', 'TT001');

DROP TABLE IF EXISTS `tlb_ctcongviec`;
CREATE TABLE `tlb_ctcongviec` (
  `cong_viec_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_cong_viec` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`cong_viec_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_ctcongviec` VALUES
('ATLD', 'An toàn lao động'),
('BV001', 'Bảo vệ'),
('CNTT', 'Công nghệ thông tin'),
('KTT001', 'Kế toán trưởng'),
('KTV001', 'Kế toán viên'),
('LT001', 'Lập trình viên'),
('TX001', 'Tài xế'),
('VT001', 'Văn thư');

DROP TABLE IF EXISTS `tlb_dantoc`;
CREATE TABLE `tlb_dantoc` (
  `dan_toc_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_dan_toc` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`dan_toc_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_dantoc` VALUES
('DT001', 'Kinh'),
('DT002', 'Mường'),
('DT003', 'Bana'),
('DT004', 'Tày'),
('DT005', 'Nùng'),
('DT006', 'Thái'),
('DT007', 'Dao'),
('DT008', 'Khơ Me'),
('DT009', 'Ê Đê'),
('DT010', 'Hơ Mông'),
('DT011', 'Mèo'),
('DT012', 'Tà Ôi'),
('DT013', 'Chăm');

DROP TABLE IF EXISTS `tlb_hinhanh`;
CREATE TABLE `tlb_hinhanh` (
  `id` mediumint(10) NOT NULL AUTO_INCREMENT,
  `ten_anh` varchar(25) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_hinhanh` VALUES
(2, '1318841686.jpg'),
(3, '1318841821.jpg'),
(4, '1318910096.jpg'),
(5, '1318910105.jpg'),
(7, '1318910124.jpg'),
(8, '1318911121.jpg'),
(9, '1318911135.jpg'),
(10, '1318911710.jpg'),
(11, '1318911868.jpg'),
(12, '');

DROP TABLE IF EXISTS `tlb_hocvan`;
CREATE TABLE `tlb_hocvan` (
  `hoc_van_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_hoc_van` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`hoc_van_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_hocvan` VALUES
('HV002', 'Lớp 7'),
('HV003', 'Lớp 8'),
('HV004', 'Lớp 9'),
('HV005', 'Lớp 12');

DROP TABLE IF EXISTS `tlb_hopdong`;
CREATE TABLE `tlb_hopdong` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `ma_nhan_vien` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `so_quyet_dinh` varchar(25) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `tu_ngay` date DEFAULT NULL,
  `den_ngay` date DEFAULT NULL,
  `loai_hop_dong` int(1) DEFAULT NULL,
  `ghi_chu` varchar(100) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_hopdong` VALUES
(1, 'TCHC008', '312/2010/QĐ-TCHC', '2010-02-03', '2012-02-02', 3, NULL),
(8, 'TCHC008', '315/2010/QĐ-TCHC', '2012-02-02', NULL, 2, 'ttttttttt'),
(9, 'TCHC008', '815/2010/QĐ-TCHC', '2012-10-10', NULL, 0, 'pppppppp'),
(10, 'TCHC008', '315/2010/QĐ-TCHC', '2012-02-02', NULL, 0, 'ttttttt');

DROP TABLE IF EXISTS `tlb_ngoaingu`;
CREATE TABLE `tlb_ngoaingu` (
  `ngoai_ngu_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_ngoai_ngu` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`ngoai_ngu_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_ngoaingu` VALUES
('AV000', 'Không'),
('AV001', 'Bằng A anh văn'),
('AV002', 'Bằng B anh văn'),
('AV003', 'Bằng C anh văn'),
('FRE', 'Tiếng Pháp'),
('RUS', 'Tiếng Nga');

DROP TABLE IF EXISTS `tlb_nguoidung`;
CREATE TABLE `tlb_nguoidung` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ten_dang_nhap` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `mat_khau` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `quyen_them` int(1) DEFAULT '0',
  `quyen_sua` int(1) DEFAULT '0',
  `quyen_xoa` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_nguoidung` VALUES
(1, 'admin', '28f9ed155d9e0ca7d1e1228e3771dde5', 1, 1, 1);

DROP TABLE IF EXISTS `tlb_nhanvien`;
CREATE TABLE `tlb_nhanvien` (
  `ma_nhan_vien` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `ho_ten` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `gioi_tinh` tinyint(1) NOT NULL,
  `gia_dinh` tinyint(1) NOT NULL,
  `dt_di_dong` varchar(15) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `dt_nha` varchar(15) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `email` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `ngay_sinh` varchar(25) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `noi_sinh` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `tinh_thanh` varchar(30) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `cmnd` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `ngay_cap` varchar(25) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `noi_cap` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `que_quan` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `dia_chi` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `tam_tru` varchar(100) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `hinh_anh` varchar(30) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT 'no_image.jpg',
  `nghi_viec` int(1) DEFAULT NULL,
  PRIMARY KEY (`ma_nhan_vien`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `tlb_nhanvien` VALUES
('TCHC008', 'Phạm Tuấn Khanh', 1, 0, '0902395848', '0676555995', 'tuankhanhptk@yahoo.com', '04/01/1983', NULL, 'Đồng Tháp', NULL, NULL, NULL, 'Đồng Tháp', 'Đồng Tháp', 'Đồng Tháp', 'untitled.JPG', 1),
('TCHC002', 'Nguyễn Hữu Trí', 1, 1, '888888888', '2222222224', 'huutrivc27@yahoo.com', NULL, NULL, 'Đồng Tháp', NULL, NULL, NULL, 'Đồng Tháp', 'Đồng Tháp', 'Đồng Tháp', 'untitled.JPG', 0),
('TCHC001', 'Dương Ngọc Thành', 1, 1, '0987016875', '0435548733', 'dieplcv@gmail.com', NULL, NULL, 'Đồng Tháp', NULL, NULL, NULL, 'Đồng Tháp', 'Đồng Tháp', 'Đồng Tháp', 'untitled.JPG', 0),
('TCHC003', 'Nguyễn Ngọc Điệp', 1, 0, '342354235235', '5324523523', 'dsfFdff@dggsdgf', NULL, NULL, NULL, NULL, NULL, NULL, 'dfasf ầ f', 'f sdgs g', ' grsy dhf d', 'dsg yjtd fg', 0),
('TCHC006', 'Trần Văn Quyền', 1, 1, '5555555555', '7777777777', 'sdadas dá@yahoo.com', NULL, NULL, 'Đồng Tháp', NULL, NULL, NULL, 'Đồng Tháp', 'Đồng Tháp', 'Đồng Tháp', 'untitled.JPG', 0);

DROP TABLE IF EXISTS `tlb_phongban`;
CREATE TABLE `tlb_phongban` (
  `phong_ban_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_phong_ban` varchar(100) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`phong_ban_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_phongban` VALUES
('CN001', 'Chi nhánh TP. HCM'),
('DXDS001', 'Đội Xây dựng số 1'),
('DXDS002', 'Đội Xây dựng số 2'),
('PKH', 'Phòng Kế hoạch'),
('PKT', 'Phòng Kỹ thuật'),
('PTCHC', 'Tổ chức Hành chính'),
('TCKT', 'Tài chính Kế toán'),
('TN001', 'Trạm thuỷ nông số 1'),
('TN002', 'Trạm thuỷ nông số 2'),
('TTTV', 'Trung tâm tư vấn');

DROP TABLE IF EXISTS `tlb_quanhegiadinh`;
CREATE TABLE `tlb_quanhegiadinh` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `ma_nhan_vien` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_nguoi_than` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `nam_sinh` int(4) NOT NULL,
  `moi_quan_he` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `nghe_nghiep` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `dia_chi` varchar(100) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `noi_lam` varchar(100) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `dtdd` varchar(20) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `dtcq` varchar(20) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `ghi_chu` varchar(200) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_quanhegiadinh` VALUES
(2, 'TCHC008', 'Đặng lệ thu', 1961, 'Mẹ', 'Nhân viên thu hoa chi chợ Cao Lãnh', 'F3-Đồng Tháp', 'Cty TNHH Hoàng Anh', '120251514', '021548785', 'f ầ sfas f ádf'),
(3, 'TCHC008', 'Phạm Thị Thuỳ Dung', 1985, 'Em', 'CNVCB', 'Đồng Tháp', NULL, '0955581815', NULL, NULL);

DROP TABLE IF EXISTS `tlb_quatrinhcongtac`;
CREATE TABLE `tlb_quatrinhcongtac` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `ma_nhan_vien` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `so_quyet_dinh` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `ngay_ky` varchar(25) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `ngay_hieu_luc` varchar(25) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `cong_viec` varchar(100) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `ghi_chu` text /*!40101 COLLATE utf8mb4_unicode_ci */,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_quatrinhcongtac` VALUES
(1, 'TCHC008', '300/2010/QĐ-TCHC', '02/02/2008', '02/02/2008', 'CNTT', 'Testtttggg'),
(2, 'TCHC008', '350/2010/QĐ-TCHC', '06/08/2009', '01/09/2009', 'Nhân viên lưu trữ', 'Phòng QLTC'),
(3, 'TCHC002', '390/2010/QĐ-TCHC', '2008-09-01', '2009-09-02', 'An toàn lao động', 'Phòng TCHC'),
(4, 'TCHC002', '305/2010/QĐ-TCHC', '2009-05-01', '2010-09-02', 'An toàn lao động 222', 'pppppppppp');

DROP TABLE IF EXISTS `tlb_quatrinhluong`;
CREATE TABLE `tlb_quatrinhluong` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `ma_nhan_vien` varchar(25) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `so_quyet_dinh` varchar(25) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `ngay_chuyen` date DEFAULT NULL,
  `muc_luong` varchar(4) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  `ghi_chu` varchar(200) /*!40101 COLLATE utf8mb4_unicode_ci */ DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_quatrinhluong` VALUES
(1, 'TCHC008', '312/2010/QĐ-TCHC', '2010-02-02', '3', '2 năm nâng bậc'),
(2, 'TCHC003', '312/2010/QĐ-TCHC', '2010-02-02', '3', NULL),
(3, 'TCHC008', '315/2010/QĐ-TCHC', '2010-02-02', '1.33', 'nâng bậc 2 năm'),
(4, NULL, NULL, NULL, NULL, NULL),
(5, NULL, NULL, NULL, NULL, NULL);

DROP TABLE IF EXISTS `tlb_quoctich`;
CREATE TABLE `tlb_quoctich` (
  `quoc_tich_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_quoc_tich` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`quoc_tich_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_quoctich` VALUES
('QT001', 'Việt Nam'),
('QT002', 'Anh'),
('QT003', 'Mỹ');

DROP TABLE IF EXISTS `tlb_tinhoc`;
CREATE TABLE `tlb_tinhoc` (
  `tin_hoc_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_tin_hoc` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`tin_hoc_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_tinhoc` VALUES
('TH000', 'Không'),
('TH001', 'Tin học A'),
('TH002', 'Tin học B'),
('TH003', 'Trung cấp');

DROP TABLE IF EXISTS `tlb_tinhthanh`;
CREATE TABLE `tlb_tinhthanh` (
  `tinh_thanh_id` varchar(10) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  `ten_tinh_thanh` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`tinh_thanh_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_tinhthanh` VALUES
('TT001', 'Đồng Tháp'),
('TT002', 'Tiền Giang'),
('TT003', 'An Giang'),
('TT004', 'Vĩnh Long'),
('TT005', 'Trà Vinh');

DROP TABLE IF EXISTS `tlb_tongiao`;
CREATE TABLE `tlb_tongiao` (
  `ton_giao_id` int(10) NOT NULL,
  `ten_ton_giao` varchar(50) /*!40101 COLLATE utf8mb4_unicode_ci */ NOT NULL,
  PRIMARY KEY (`ton_giao_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8mb4 */ /*!40101 COLLATE=utf8mb4_unicode_ci */;

INSERT INTO `tlb_tongiao` VALUES
(1, 'Không'),
(2, 'Cao Đài'),
(3, 'Thiên Chúa'),
(4, 'Đạo Phật');

